Support FR4 Print only
This Print has no copper and acts as Panel Support for activity tracker Panel:
Projet Name: WEH_Activity_Tracker_0v2.0

Layers:
GM4: Outline
TXT: Drill File
